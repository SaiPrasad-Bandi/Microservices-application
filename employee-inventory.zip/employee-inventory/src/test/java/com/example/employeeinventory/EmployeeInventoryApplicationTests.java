package com.example.employeeinventory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeInventoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
