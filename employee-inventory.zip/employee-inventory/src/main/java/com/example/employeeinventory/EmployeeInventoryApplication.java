package com.example.employeeinventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeInventoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeInventoryApplication.class, args);
	}

}
